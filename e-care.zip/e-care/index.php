<?php
ob_start();
include('conn/conn.php');
?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>E-CARE | LOG IN OR SIGN UP</title>

	<script src="js/jquery-2.1.1.min.js"></script>
</head>

<body>
	
	<div style="float:right">
		<!-- LOGIN FORM -->
		<h4>Sign In to your account</h4>
		<div id="success"></div>
		<form action = "login.php" method= "post" id="demo-bvd-notempty">
			<input type="text" placeholder="Enter your Email" name="email" required>
			<input type="password" placeholder="Password" name="password" required>
			<br><br>
			<label class="form-checkbox form-icon">
				<input type="checkbox"> Remember me
			</label>
			<input  type="submit" name="login" value="Sign In">
							
		</form><br>	
		<div>
			<a href="edit_user.php">Forgot password ? OR Change Password ?</a>
			<a href="useraccount.php">Create a new account</a>
		</div>
	</div>
	
	<script type="text/javascript">
		$(document).on("submit", "form", function(event)
		{
		  event.preventDefault();        
		    $.ajax({
		        url: "login.php",//$(this).attr("action"),
		        type: $(this).attr("method"),
		       // dataType: "JSON",
		        data: new FormData(this),
		        processData: false,
		        contentType: false,
		        success: function (results)
		        {         
				  $('#success').html(results);

		        },
		        error: function (xhr, desc, err)
		        {
		         }
		    });        
		});
	</script>

</body>
</html>
