<?php
include('../conn/pat_session.php');
include('../conn/conn.php');
error_reporting(E_ALL ^ E_NOTICE);
?>

<!DOCTYPE html>
<html lang="en"><head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>E-CARE | Home</title>
</head>
<body>

	<h2>Patient home page</h2><a style="float:right" href="logout.php">Logout</a>
	<!--jQuery [ REQUIRED ]-->
	<script src="../js/jquery-2.1.1.min.js"></script>

</body>


</html>
